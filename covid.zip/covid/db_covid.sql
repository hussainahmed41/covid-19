-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2020 at 02:22 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_area`
--

CREATE TABLE `tbl_area` (
  `area_id` int(11) NOT NULL,
  `division_id` int(255) NOT NULL,
  `area_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_area`
--

INSERT INTO `tbl_area` (`area_id`, `division_id`, `area_name`) VALUES
(1, 1, 'Bishwanath'),
(2, 1, 'Janaiya'),
(4, 2, 'Shabag'),
(5, 1, 'LamaKaji'),
(6, 1, 'Lala Bajar'),
(7, 1, 'Lal Bajar'),
(8, 1, 'Guawala Bajar'),
(9, 1, 'Osmani Nagar'),
(10, 1, 'Najir Bajar'),
(11, 1, 'Kuruwa'),
(12, 1, 'Doyamir'),
(13, 1, 'Rsohidpur'),
(14, 1, 'Bagicha Bajar'),
(15, 1, 'Khali  Ganj'),
(16, 1, 'Moyna Ganj'),
(17, 1, 'Firer Bajar'),
(18, 1, 'Doshghar'),
(19, 1, 'Mirpur'),
(20, 1, 'Jagannathpur'),
(21, 1, 'Baushi'),
(22, 1, 'Tengra'),
(23, 1, 'Noki khali'),
(24, 1, 'Rampasha'),
(25, 1, 'Gobind Ganj'),
(26, 1, 'Bondor'),
(27, 1, 'Noya Shorok'),
(28, 1, 'Shah Poran'),
(29, 1, 'Ambarkhana'),
(30, 1, 'Zinda Bajar'),
(31, 1, 'Chowtta'),
(32, 1, 'Akhali'),
(33, 1, 'Modina Market'),
(34, 1, 'Kali Bari'),
(35, 1, 'Temukhi'),
(36, 1, 'Mirer Moydan'),
(37, 1, 'Medical Road'),
(38, 1, 'Nobab Road'),
(39, 1, 'Sekh Ghat'),
(40, 1, 'Kajir Bajar'),
(41, 1, 'Rikabi Bajar'),
(42, 1, 'Subid Bajar'),
(43, 1, 'Mirja Jangle'),
(44, 1, 'Tal tola'),
(45, 1, 'Baruth Khana'),
(46, 1, 'Bateshawar'),
(47, 2, 'Mirpur'),
(48, 2, 'Shahbag'),
(49, 2, 'SHapla Chattar'),
(50, 2, 'Kola Bagan'),
(51, 2, 'Gajipur'),
(52, 2, 'Tongi'),
(53, 2, 'Saydabad'),
(54, 62, 'Chunaru ghat'),
(55, 1, 'Zakiganj '),
(56, 1, 'Kanaighat'),
(57, 1, 'Companiganj'),
(58, 1, 'Gowainghat'),
(59, 1, 'Golabganj'),
(60, 1, 'Jaintiapur '),
(61, 1, 'Dakshin Surma'),
(62, 1, 'Fenchuganj'),
(63, 1, 'Balaganj'),
(64, 1, 'Beanibazar'),
(65, 1, 'Sylhet Sadar');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_division`
--

CREATE TABLE `tbl_division` (
  `div_id` int(11) NOT NULL,
  `division_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_division`
--

INSERT INTO `tbl_division` (`div_id`, `division_name`) VALUES
(1, 'Sylhet'),
(2, 'Dhaka'),
(3, 'Chittagong'),
(4, 'Cumilla'),
(5, 'Khulna'),
(6, 'Rajshahi'),
(7, 'Jessore'),
(8, 'Rangpur'),
(9, 'Barishal'),
(10, 'Barguna'),
(11, 'Bhola '),
(12, 'Jhalokati '),
(13, 'Patuakhali'),
(14, 'Pirojpur '),
(15, 'Bandarban'),
(16, 'Brahmanbaria'),
(17, 'Chandpur'),
(18, 'Coxs Bazar '),
(19, 'Feni'),
(20, 'Khagrachhari'),
(21, 'Lakshmipur'),
(22, 'Noakhali'),
(23, 'Rangamati'),
(24, 'Faridpur '),
(25, 'Gazipur'),
(26, 'Gopalganj '),
(27, 'Kishoreganj'),
(28, 'Madaripur'),
(29, 'Manikganj '),
(30, 'Munshiganj'),
(31, 'Narayanganj'),
(32, 'Narsingdi'),
(33, 'Rajbari'),
(34, 'Shariatpur'),
(35, 'Tangail '),
(36, 'Bagerhat'),
(37, 'Chuadanga'),
(38, 'Jhenaidah '),
(39, 'Kushtia '),
(40, 'Magura'),
(41, 'Meherpur '),
(42, 'Narail'),
(43, 'Satkhira'),
(44, 'Jamalpur'),
(45, 'Mymensingh'),
(46, 'Netrokona '),
(47, 'Sherpur '),
(48, 'Bogra '),
(49, 'Joypurhat'),
(50, 'Naogaon '),
(51, 'Natore'),
(52, 'Chapainawabganj'),
(53, 'Pabna'),
(54, 'Sirajganj'),
(55, 'Dinajpur'),
(56, 'Gaibandha'),
(57, 'Kurigram'),
(58, 'Lalmonirhat'),
(59, 'Nilphamari'),
(60, 'Panchagarh'),
(61, 'Thakurgaon'),
(62, 'Habiganj'),
(63, 'Moulvibazar'),
(64, 'Sunamganj ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `message_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_message`
--

INSERT INTO `tbl_message` (`message_id`, `name`, `mobile`, `email`, `message`) VALUES
(1, 'Hussain', '1796648208', '', 'i am not okay'),
(5, 'Jyoti Begum', '01647034710', '', ' I fell like little bit of sick with cough and cattrh.now what should i do? tell me about the tratment.'),
(6, 'Hussain Ahmed', '01647034710', 'ha45474@gmail.com', ' i am a strong person but nowdays i am felling uncomfortable about my health..what shoukd i do now?'),
(8, 'Hussain Ahmed Munna', '01647034710', 'hussain@gmail.com', ' i am fine by the grace of allah');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `post_name` varchar(255) NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `post_detail` varchar(255) NOT NULL,
  `post_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `post_name`, `post_date`, `post_detail`, `post_photo`) VALUES
(13, 'Covid vaccine update: When will others be ready?', '1607623200', 'A Covid vaccine developed by Pfizer/BioNtech has been approved for use in the UK and the first doses have been given to patients.\r\n\r\nBut how does it compare with other vaccines under development?\r\nWhy do we need a vaccine?\r\n\r\nThe vast majority of people a', 'vacsine.jpg'),
(14, 'How will winter affect the way coronavirus spreads?', '1607623200', 'Winter is on its way. And in this year of coronavirus, comes the potential for a second wave of COVID-19. Add in flu season and our tendency to head inside and close our windows to the cold, wet weather, and it appears the next several months are going to', '43.jpg'),
(17, 'Vacsine available in BD', '1608400800', 'orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has sur', '3_-_Copy1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `weight` int(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `division_id` int(11) NOT NULL,
  `conditions` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `address`, `gender`, `email`, `mobile`, `dob`, `weight`, `password`, `division_id`, `conditions`, `type`) VALUES
(1, '', '', '', 'admin@gmail.com', '', '0000-00-00', 0, '112233', 0, '', 'Admin'),
(2, 'Hussain Ahmed', 'Bishwanath,Sylhet', 'male', 'hussain@gmail.com', '01796648209', '1996-10-23', 60, '111', 2, 'ILL', 'user'),
(3, 'Fahim Ahmed', 'Bishwanath,Sylhet', 'male', 'fahmi@gmail.com', '01611553322', '1996-10-11', 55, '111', 7, 'ILL', 'user'),
(4, 'Sumon Ahmed', 'biswanath,sylhet', 'male', 'sumon@gmail.com', '01766448844', '1992-08-15', 67, '222', 1, 'ILL', 'user'),
(5, 'Fahmida Akter ', 'Akhali', 'female', 'fahmida@gmail.com', '01877553399', '1997-12-12', 52, '2121', 1, 'ILL', 'user'),
(6, 'Anuwara begum', 'Sylhet', 'female', 'anuwara@gmail.com', '01342527266', '1998-11-25', 49, '6655', 1, 'WELL', 'user'),
(7, 'Abu jafor', 'Sylhet', 'male', 'jafor@gmail.com', '017965453254', '1996-12-10', 76, '9988', 1, 'ILL', 'user'),
(8, 'Taslima Begum', 'Mirpur', 'female', 'taslima@gmail.com', '01362754538', '1990-03-23', 66, '5537', 2, 'WELL', 'user'),
(9, 'Taiob Ali', 'Bondor Bajar', 'male', 'taiob@gmail.com', '017965427688', '1991-12-10', 73, '9980', 1, 'ILL', 'user'),
(10, 'Lima Begum', 'Mohakali', 'female', 'lima@gmail.com', '01654342789', '1999-06-28', 40, '4455', 2, 'WELL', 'user'),
(11, 'Sojib  Chandra Das', 'Sylhet', 'male', 'sojib@gmail.com', '01854327865', '1997-11-07', 90, '0099', 1, 'WELL', 'user'),
(12, 'Fariha Tasnim', 'Chunarughat', 'female', 'fariha@gmail.com', '01987654321', '1997-10-23', 55, '7676', 62, 'WELL', 'user'),
(13, 'Hasan Ahmed', 'Bishwanath,Sylhet', 'male', 'hasan@gmail.com', '01654673281', '2006-08-08', 34, '8989', 1, 'ILL', 'user'),
(14, 'Sahnin Ahmed', 'Bishwanath,Sylhet', 'male', 'sahin@gmail.com', '01676544890', '1996-10-12', 66, '123123', 1, 'ILL', 'user'),
(15, 'Anam Uddin', 'Jagannathpur', 'male', 'anam@gmail.com', '01654673281', '1990-04-07', 78, '8877', 1, 'WELL', 'user'),
(16, 'Khaleda Zia', 'Lamakaji', 'female', 'khaleda@gmail.com', '01611553322', '1990-12-10', 88, '0000', 1, 'WELL', 'user'),
(17, 'Hasina Begum', 'Lamakaji', 'female', 'hasina@gmail.com', '01362754538', '1960-11-15', 90, '4343', 1, 'ILL', 'user'),
(18, 'Ahnaf Redwan', 'Rampasha, Bishwanath', 'male', 'Ahnaf@gmail.com', '01654342789', '1990-03-05', 77, '887766', 1, 'WELL', 'user'),
(19, 'Rasel Ahmed', 'DoshGhor,Bishwanath', 'male', 'rasel@gmail.com', '01654342789', '1998-06-07', 66, '443322', 1, 'ILL', 'user'),
(20, 'Rajon Ahmed', 'najir Bajar', 'male', 'rajon@gmail.com', '01342527266', '1996-06-07', 80, '111', 1, 'ILL', 'user'),
(21, 'Sujon Ahmed', 'kuruwa', 'male', 'sujon@gmail.com', '01362754538', '1990-02-05', 76, '3333', 1, 'WELL', 'user'),
(22, 'Shakir Ali', 'Rampasha, Bishwanath', 'male', 'shakir@gmail.com', '01654673281', '1998-05-07', 76, '0009', 1, 'ILL', 'user'),
(23, 'Suyeb Ahmed', 'DoshGhor,Bishwanath', 'male', 'suyeb@gmail.com', '01654673281', '1999-08-04', 55, '1234', 1, 'ILL', 'user'),
(24, 'Sahin ', 'Najir Bajar', 'male', 'sahin@gmail.com', '01362754538', '2000-07-04', 61, '8888', 1, 'WELL', 'user'),
(27, 'Koyrun Nesa', 'Lamakaji', 'female', 'koyrun@gmail.com', '01654673281', '1970-01-01', 77, '111', 1, 'ILL', 'user'),
(28, 'Tarek Ali', 'Zindabajar', 'male', 'tarek@gmail.com', '01654342789', '1990-06-07', 55, '554466', 1, 'ILL', 'user'),
(29, 'Tahfim', 'Sylhet Sadar', 'male', 'tahfim@gmail.com', '01654342789', '2000-04-06', 45, '789', 1, 'ILL', 'user'),
(30, 'Jony Begum', 'Lal Bajar', 'female', 'jony@gmail.com', '01654342789', '1992-04-08', 64, '5890', 1, 'ILL', 'user'),
(31, 'Suchona begum', 'Janaiya', 'female', 'suchona@gmail.com', '01611553322', '1994-02-09', 88, '221133', 1, 'ILL', 'user'),
(32, 'Ojana Akter', 'Zindabajar', 'female', 'ojana@gmail.com', '01611553322', '1997-03-04', 50, '6655', 1, 'ILL', 'user'),
(33, 'Habibur Rahman', 'Dakhin surma', 'male', 'habib@gmail.com', '01676544890', '1997-10-02', 87, '9999', 1, 'ILL', 'user'),
(34, 'Maya Begum', 'kali bari', 'female', 'maya@gmail.com', '01654342789', '1965-10-11', 54, '2424', 1, 'ILL', 'user'),
(35, 'Sunu Miah', 'Roshidpur', 'male', 'sunu@gmail.com', '01362754538', '1990-02-12', 66, '332243', 1, 'ILL', 'user'),
(36, 'Asadujjaman', 'Gajipur', 'male', 'asad@gmail.com', '01654342789', '1990-04-06', 77, '6677', 2, 'ILL', 'user'),
(37, 'Rasel Ahmed', 'Mirpur', 'male', 'rasel@gmail.com', '01654673281', '1998-03-08', 76, '7777', 2, 'ILL', 'user'),
(38, 'Layek Ahmed', 'Rampura', 'male', 'layekA@gmail.com', '01362754538', '1995-07-05', 90, '2233', 2, 'WELL', 'user'),
(39, 'Tanjina', 'Saydabad', 'female', 'tanjina@gmail.com', '01676544890', '1999-02-06', 66, '0000', 2, 'ILL', 'user'),
(40, 'Tamim Iqbal', 'Dhanmondi', 'male', 'iqbal@gmail.com', '01362754538', '1986-04-11', 69, '6565', 2, 'ILL', 'user'),
(41, 'Shakib Al Hasan', 'Boshundora', 'male', 'Shakib@gmail.com', '01676544890', '1979-04-11', 70, '1111', 2, 'WELL', 'user'),
(42, 'Ahnaf Sami', '', '', 'sami@gmail.com', '', '0000-00-00', 0, '1111', 0, '', 'user'),
(43, 'Samiyan Ahmed', '', '', 'samiyan@gmail.com', '', '0000-00-00', 0, '4444', 0, '', 'user'),
(44, 'Rabbani', 'raypura', 'male', 'rabbani@gmail.com', '01611553322', '1990-05-04', 76, '6565', 9, 'ILL', 'user'),
(45, 'Jannath Begum', 'jahargaw', 'female', 'jannath@gmail.com', '01611553322', '1997-12-31', 55, '7777', 9, 'ILL', 'user'),
(46, 'Heera Miah', 'janata polli', 'male', 'heera@gmail.com', '01654673281', '1991-11-07', 88, '8989', 9, 'ILL', 'user'),
(47, 'Fozlu Miah', 'mohastan', 'male', 'fojlu@gmail.com', '01654673281', '1981-12-12', 100, '3333', 9, 'ILL', 'user'),
(48, 'Sebul Miah', 'Shurir khal', 'male', 'sebul@gmail.com', '01654342789', '1998-12-12', 108, '1212', 9, 'ILL', 'user'),
(49, 'Abdul Ali', 'jahanar monjil', 'male', 'ali@gmail.com', '01362754538', '1997-11-11', 52, '0000', 9, 'ILL', 'user'),
(50, 'Amina Begum', 'Boiddokafon', 'female', 'begum@gmail.com', '01611553322', '1997-10-10', 44, '5555', 9, 'WELL', 'user'),
(51, 'Tahrim', 'potenga', 'female', 'tahrim@gmail.com', '01362754538', '1990-04-08', 88, '3333', 3, 'ILL', 'user'),
(52, 'Ahmed Ali', 'Bishwanath,Sylhet', 'male', 'ahmed@gmail.com', '01796648209', '1996-10-23', 55, '123', 1, '', 'user'),
(53, 'Tufayel Ahmed', 'Lamakaji,Rampasha', 'male', 'tufayelahmed@gmail.com', '016470347100', '1998-11-12', 56, '123', 1, 'WELL', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_area`
--
ALTER TABLE `tbl_area`
  ADD PRIMARY KEY (`area_id`);

--
-- Indexes for table `tbl_division`
--
ALTER TABLE `tbl_division`
  ADD PRIMARY KEY (`div_id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_area`
--
ALTER TABLE `tbl_area`
  MODIFY `area_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `tbl_division`
--
ALTER TABLE `tbl_division`
  MODIFY `div_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
