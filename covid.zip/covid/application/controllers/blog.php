<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class blog extends CI_Controller {

	
	public function index()
	{
		$data['post']=$this->db->get('tbl_post')->result_array();
            
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('blog',$data);
		$this->load->view('inc/footer');
	}
	
	
	public function view_post()
	{
		
			$data['post']=$this->db->get('tbl_post')->result_array();
             

		
		$this->load->view('inc/header');
		 $this->load->view('inc/navbar');
		 $this->load->view('blog',$data);
		 $this->load->view('inc/footer');
		 
	}
	
}
