<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user_dashboard extends CI_Controller {
       function __construct() {
        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if(!($this->session->userdata('type'))=='Admin'){
			redirect('welcome');
		}else{
		
		}


    }
	
	public function index()
	{
		$this->load->view('user_dashboard/inc/header');
		$this->load->view('user_dashboard/inc/navbar2');
		$this->load->view('user_dashboard/dashboard');
		$this->load->view('user_dashboard/inc/footer');
	}
	
	public function add_user()
	{
		
		
		$this->form_validation->set_rules('weight', 'weight', 'required|regex_match[/^[0-9 ]+$/]');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
			
		if ($this->form_validation->run() == FALSE)
		{

			$edata['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('user_dashboard/inc/header');
		 $this->load->view('user_dashboard/inc/navbar2');
		 $this->load->view('user_dashboard/otherinfo',$edata);
		 $this->load->view('user_dashboard/inc/footer');
			
		}else{
			
			
				
				$idata['weight']=$this->input->post('weight');
				$idata['mobile']=$this->input->post('mobile');
				$idata['dob']=date('Y-m-d',strtotime($this->input->post('dob')));
				$idata['address']=$this->input->post('address');
				$idata['gender']=$this->input->post('gender');
				$idata['division_id']=$this->input->post('division_id');
				$idata['type']='user';
				


				$this->db->insert('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('otherinfo');
			
		}
		
	}

	public function edit_otherinfo()
	{

		$this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('confirm_password', 'confirm_password', 'required|matches[password]');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('weight', 'weight', 'required|regex_match[/^[0-9 ]+$/]');
		$this->form_validation->set_rules('address', 'Address', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
		
		
		
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['user']=$this->db->where('id',$this->session->userdata('id'))->get('tbl_user')->result_array();
			$data['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('user_dashboard/inc/header');
		$this->load->view('user_dashboard/inc/navbar2');
		 $this->load->view('user_dashboard/edit-otherinfo',$data);
		 $this->load->view('user_dashboard/inc/footer');
			
		}else{
			
			
				
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['mobile']=$this->input->post('mobile');
				$idata['weight']=$this->input->post('weight');
				$idata['dob']=date('Y-m-d',strtotime($this->input->post('dob')));
				$idata['address']=$this->input->post('address');
				$idata['gender']=$this->input->post('gender');
				$idata['password']=$this->input->post('password');
				$idata['division_id']=$this->input->post('division_id');
				$idata['type']='user';
				
				


				$this->db->where('id',$this->session->userdata('id'));
				$this->db->update('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Updated</div>';

				$this->session->set_flashdata('success',$message);

				redirect($_SERVER['HTTP_REFERER']);
			
			
		}
		  
	}
	
	public function area_search()
	{
		
		
		
		
		$this->form_validation->set_rules('division_id', 'Destination name', 'required');
 
		$this->form_validation->set_message('required', 'Select a %s or Area Please!');
		
			
		if ($this->form_validation->run() == FALSE)
		{

			$edata['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('user_dashboard/inc/header');
		 $this->load->view('user_dashboard/inc/navbar2');
		 $this->load->view('user_dashboard/area-search',$edata);
		 $this->load->view('user_dashboard/inc/footer');
			
		}else{
			
			
				
				
				$d_id=$this->input->post('division_id');
				
				


				$total_ILL=$this->db->where('conditions','ILL')->where('division_id',$d_id)->get('tbl_user')->num_rows();
                 $total_patient=$this->db->where('division_id',$d_id)->get('tbl_user')->num_rows();
				 
				 if($total_patient>0){
					 
                $total_risk=number_format((($total_ILL/$total_patient)*100),2);
				
				if ($total_risk>=0 && $total_risk<=10){
				 
				$message='<div class="alert alert-success">Moderate Risk<br>A little number of peoples are affected by CORONA Virus in this area.10% peoples are having by the virus among the boy,girls,babiess and adults. So please,Wear Mask and take your safety</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=11 && $total_risk<=50){
				 
				$message='<div class="alert alert-warning">Terrible Condition<br>50% peoples are having by the COVID-19 in this area among the Adults,Young and Babies. Dangerous Area to travell, so Wear Mask,use PPE and keep hand gloves Please</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=51 && $total_risk<=70){
				 
				$message='<div class="alert alert-warning">Highly Risk Area<br>Strongly recommended to stay safe and carefull in this area.<br>More than 60% peoples are Effected by Corona virus at this circumstances.So please  saty safe and use PPE.</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=71 && $total_risk<=100){
				 
				$message='<div class="alert alert-danger">Highly COVID spreading area,Not recommended to visit.Keep PPE with your self,Use Mask,Hand Gloves,protective eye Glass,Face shield,Hand Senitizer too<br>Be carefull!</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}

				
				 }else{
					  
				$message='<div class="alert alert-success">No patients in This Area.Risk Free </div>';

					$this->session->set_flashdata('success',$message);
	 
				 }
				 
				 
                $this->session->set_flashdata('division_id',$d_id);
				
				redirect('user_dashboard/area-search');
			
		}
		
	}
	public function subarea_search()
	{
		
		
		
		
		$this->form_validation->set_rules('area_id', 'Destination name', 'required');
 
		$this->form_validation->set_message('required', 'Select a %s or Area Please!');
		
			
		if ($this->form_validation->run() == FALSE)
		{

			$edata['area']=$this->db->get('tbl_area')->result_array();

		$this->load->view('user_dashboard/inc/header');
		 $this->load->view('user_dashboard/inc/navbar2');
		 $this->load->view('user_dashboard/subarea-search',$edata);
		 $this->load->view('user_dashboard/inc/footer');
			
		}else{
			
			
				
				
				$d_id=$this->input->post('area_id');
				
				


				$total_ILL=$this->db->where('conditions','ILL')->where('area_id',$d_id)->get('tbl_user')->num_rows();
                 $total_patient=$this->db->where('area_id',$d_id)->get('tbl_user')->num_rows();
				 
				 if($total_patient>0){
					 
                $total_risk=number_format((($total_ILL/$total_patient)*100),2);
				
				if ($total_risk>=0 && $total_risk<=10){
				 
				$message='<div class="alert alert-success">Moderate Risk<br>A little number of peoples are affected by CORONA Virus in this area.10% peoples are having by the virus among the boy,girls,babiess and adults. So please,Wear Mask and take your safety</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=11 && $total_risk<=50){
				 
				$message='<div class="alert alert-warning">Terrible Condition<br>50% peoples are having by the COVID-19 in this area among the Adults,Young and Babies. Dangerous Area to travell, so Wear Mask,use PPE and keep hand gloves Please</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=51 && $total_risk<=70){
				 
				$message='<div class="alert alert-warning">Highly Risk Area<br>Strongly recommended to stay safe and carefull in this area.<br>More than 60% peoples are Effected by Corona virus at this circumstances.So please  saty safe and use PPE.</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}elseif($total_risk>=71 && $total_risk<=100){
				 
				$message='<div class="alert alert-danger">Highly COVID spreading area,Not recommended to visit.Keep PPE with your self,Use Mask,Hand Gloves,protective eye Glass,Face shield,Hand Senitizer too<br>Be carefull!</div>';

				$this->session->set_flashdata('success',$message);
	
					
				}

				
				 }else{
					  
				$message='<div class="alert alert-success">No patients in This Area.Risk Free </div>';

					$this->session->set_flashdata('success',$message);
	 
				 }
				 
				 
                
				
				redirect('user_dashboard/subarea-search');
			
		}
	}
}
