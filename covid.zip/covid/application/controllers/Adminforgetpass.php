<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adminforgetpass extends CI_Controller {

	
	public function index()
	{
		$this->load->view('admin/inc/header');
		$this->load->view('admin/forget-pass');
		$this->load->view('admin/inc/footer');
	}
}
