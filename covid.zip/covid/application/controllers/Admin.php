<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
 	  function __construct() {
        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if(!($this->session->userdata('type'))=='Admin'){
			redirect('welcome');
		}else{
		
		}


    }
	public function index()
	{
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/dashboard');
		 $this->load->view('admin/inc/footer');
	}
	
	public function add_user()
	{
		
		
		$this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('confirm_password', 'confirm_password', 'required|matches[password]');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('weight', 'weight', 'required|regex_match[/^[0-9 ]+$/]');
		$this->form_validation->set_rules('address', 'Address', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('conditions', 'conditions', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
		
		
		
	
		
		if ($this->form_validation->run() == FALSE)
		{

				$edata['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/add-user',$edata);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['mobile']=$this->input->post('mobile');
				$idata['weight']=$this->input->post('weight');
				$idata['dob']=date('Y-m-d',strtotime($this->input->post('dob')));
				$idata['address']=$this->input->post('address');
				$idata['gender']=$this->input->post('gender');
				$idata['conditions']=$this->input->post('conditions');
				$idata['password']=$this->input->post('password');
				$idata['division_id']=$this->input->post('division_id');
				$idata['type']='user';
				


				$this->db->insert('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('Admin/add-user');
			
			
		}
		
		
		 
	}
	
	
	public function view_user()
	{
		
		$data['user']=$this->db->select('*')->from('tbl_user,tbl_division')->where('tbl_user.division_id=tbl_division.div_id')->get()->result_array();


		
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/view-user',$data);
		 $this->load->view('admin/inc/footer');
		 
	}
	
	
	public function delete_user($id)
	{
		
		$this->db->where('id',$id)->delete('tbl_user');
		
		 
		redirect('Admin/view-user');
		 
		 
	}


	
	
	public function edit_user($id)
	{

		$this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('confirm_password', 'confirm_password', 'required|matches[password]');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('weight', 'weight', 'required|regex_match[/^[0-9 ]+$/]');
		$this->form_validation->set_rules('address', 'Address', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('conditions', 'conditions', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
		
		
		
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['user']=$this->db->where('id',$id)->get('tbl_user')->result_array();
			$data['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/edit-user',$data);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['mobile']=$this->input->post('mobile');
				$idata['weight']=$this->input->post('weight');
				$idata['dob']=date('Y-m-d',strtotime($this->input->post('dob')));
				$idata['address']=$this->input->post('address');
				$idata['gender']=$this->input->post('gender');
				$idata['conditions']=$this->input->post('conditions');
				$idata['password']=$this->input->post('password');
				$idata['division_id']=$this->input->post('division_id');
				
				


				$this->db->where('id',$id);
				$this->db->update('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Updated</div>';

				$this->session->set_flashdata('success',$message);

				redirect($_SERVER['HTTP_REFERER']);
			
			
		}
		  
	}
	
	
	
	public function add_division()
	{
		
		
		$this->form_validation->set_rules('division_name', 'division name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
		
		
		
	
		
		if ($this->form_validation->run() == FALSE)
		{
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/add-division');
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				$idata['division_name']=$this->input->post('division_name');
				
				


			    $this->db->insert('tbl_division',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('Admin/add-division');
			
			
		}
		
		
		 
	}
	
	public function view_division()
	{
		
			$data['user']=$this->db->get('tbl_division')->result_array();
           

		
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/view-division',$data);
		 $this->load->view('admin/inc/footer');
		 
	}
	
	
	public function delete_division($id)
	{
		
		$this->db->where('div_id',$id)->delete('tbl_division');
		
		 
		redirect('Admin/view-division');
		 
		 
	}
	
	
		public function edit_division($id)
	{

		$this->form_validation->set_rules('division_name', 'division name', 'required');
 
		
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
		
		
		
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['user']=$this->db->where('div_id',$id)->get('tbl_division')->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/edit-division',$data);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				
				
				$idata['division_name']=$this->input->post('division_name');
				
				


				$this->db->where('div_id',$id);
				$this->db->update('tbl_division',$idata);

				$message='<div class="alert alert-success">Data Updated</div>';

				$this->session->set_flashdata('success',$message);

				redirect ('Admin/edit-division/'.$id);
			
			
		}
		  
	}
	
    
	public function add_area()
	{
		
		
		
		$this->form_validation->set_rules('area_name', 'Area', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
			
		if ($this->form_validation->run() == FALSE)
		{

			$edata['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/add-area',$edata);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				
				
				$idata['area_name']=$this->input->post('area_name');
				$idata['division_id']=$this->input->post('division_id');
				
				


				$this->db->insert('tbl_area',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('Admin/add-area');
			
		}
		
	}
public function view_area()
	{
		
			//$data['user']=$this->db->get('tbl_area')->result_array();
              $data['user']=$this->db->select('*')->from('tbl_area,tbl_division')->where('tbl_area.division_id=tbl_division.div_id')->get()->result_array();
 
		
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/view-area',$data);
		 $this->load->view('admin/inc/footer');
		 
	}

public function delete_area($id)
	{
		
		$this->db->where('area_id',$id)->delete('tbl_area');
		
		 
		redirect('Admin/view-area');
		 
		 
	}
	
public function edit_area($id)
	{

		$this->form_validation->set_rules('area_name', 'Area name', 'required');
		$this->form_validation->set_rules('division_id', 'division name', 'required');
 
		
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
		
		
		
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['user']=$this->db->where('area_id',$id)->get('tbl_area')->result_array();
           $data['division']=$this->db->get('tbl_division')->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/edit-area',$data);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				
				
				$idata['area_name']=$this->input->post('area_name');
				$idata['division_id']=$this->input->post('division_id');
				
				


				$this->db->where('area_id',$id);
				$this->db->update('tbl_area',$idata);

				$message='<div class="alert alert-success">Data Updated</div>';

				$this->session->set_flashdata('success',$message);

				redirect($_SERVER['HTTP_REFERER']);
			
			
		}
		  
	}
	
	
	public function view_message()
	{
		
			$data['user']=$this->db->get('tbl_message')->result_array();
             

		
		$this->load->view('Admin/inc/header');
		$this->load->view('Admin/inc/navbar2');
		$this->load->view('Admin/view-messages',$data);
		$this->load->view('Admin/inc/footer');
		 
	}
	public function delete_message($id)
	{
		
		$this->db->where('message_id',$id)->delete('tbl_message');
		
		 
		redirect($_SERVER['HTTP_REFERER']);
		 
		 
	}

	public function edit_otherinfo()
	{

		$this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('confirm_password', 'confirm_password', 'required|matches[password]');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('weight', 'weight', 'required|regex_match[/^[0-9 ]+$/]');
		$this->form_validation->set_rules('address', 'Address', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('division_id', 'division name', 'required|regex_match[/^[,a-zA-Z ]+$/]');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('conditions', 'conditions', 'required');
		$this->form_validation->set_rules('type', 'type', 'required');
		
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
		if ($this->form_validation->run() == FALSE)
		{
			
			$data['user']=$this->db->where('id',$this->session->userdata('id'))->get('tbl_user')->result_array();
			$data['division']=$this->db->get('tbl_division')->result_array();

			
		$this->load->view('admin/inc/header');
		 $this->load->view('admin/inc/navbar2');
		 $this->load->view('admin/edit-otherinfo',$data);
		 $this->load->view('admin/inc/footer');
			
		}else{
			
			
				
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['mobile']=$this->input->post('mobile');
				$idata['weight']=$this->input->post('weight');
				$idata['dob']=date('Y-m-d',strtotime($this->input->post('dob')));
				$idata['address']=$this->input->post('address');
				$idata['gender']=$this->input->post('gender');
				$idata['conditions']=$this->input->post('conditions');
				$idata['division_id']=$this->input->post('division_id');
				$idata['password']=$this->input->post('password');
				$idata['type']='Admin';
				


				$this->db->where('id',$id);
				$this->db->update('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Updated</div>';

				$this->session->set_flashdata('success',$message);

				redirect($_SERVER['HTTP_REFERER']);
			
			
		}
		  
	}
	
   public function Add_post()
	{
		 
		 $this->form_validation->set_rules('post_name', 'post Name', 'required');
		 $this->form_validation->set_rules('post_date', 'post Date', 'required');
		 $this->form_validation->set_rules('post_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {
		 

			$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		$this->load->view('admin/add-post');
		 $this->load->view('admin/inc/footer');

		}else{

			$idata['post_name']=$this->input->post('post_name');
			$idata['post_date']=strtotime($this->input->post('post_date'));
			$idata['post_detail']=$this->input->post('post_detail');
	
			 

				if(!empty($_FILES) && ($_FILES['post_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('post_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

	
				} else {
			 
				$avatar = $this->upload->data();
				$post_photo = $avatar['file_name'];

				$idata['post_photo']=$post_photo;

			 

				}

						 

			}else{
			
			$message='<div class="alert alert-danger">Please Add Your Image</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/add-post');

			}

			$this->db->insert('tbl_post',$idata);

			$message='<div class="alert alert-success">Post Added</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Add-post');

		}

		 

	}


	public function View_post()
	{
		$data['post']=$this->db->select('*')->from('tbl_post')->get()->result_array();

		$this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		$this->load->view('admin/view-post',$data);
		 $this->load->view('admin/inc/footer');


	}



	public function Delete_post($id="")
	{

	 
			$this->db->where('id',$id)->delete('tbl_post');

			redirect($_SERVER['HTTP_REFERER']);
	 

	}




	public function Edit_post($id)
	{
		 
		 $this->form_validation->set_rules('post_name', 'post Name', 'required');
		 $this->form_validation->set_rules('post_date', 'post Rent', 'required');
		 $this->form_validation->set_rules('post_detail', 'Deatil', 'required');


		 if ($this->form_validation->run() == FALSE)
		 {

		 $edata['post']=$this->db->where('id',$id)->get('tbl_post')->result_array();
		 

		 $this->load->view('admin/inc/header');
		$this->load->view('admin/inc/navbar2');
		$this->load->view('admin/edit-post',$edata);
		 $this->load->view('admin/inc/footer');

		}else{

			$idata['post_name']=$this->input->post('post_name');
			$idata['post_date']=strtotime($this->input->post('post_date'));
			$idata['post_detail']=$this->input->post('post_detail');
	
			 
			
			if(!empty($_FILES) && ($_FILES['post_photo']['name'])){
			

				$config['upload_path'] = 'image/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$this->load->library('upload', $config);

			
				if (!$this->upload->do_upload('post_photo')) {
				$this->session->set_flashdata('message', $this->upload->display_errors());

				redirect('Admin/Edit-post/'.$id);

				} else {
			

				$img_link=$this->db->where('id',$id)->get('tbl_post')->result_array()[0]['image'];
			
			

				 unlink('image/'.$img_link.'');


				$avatar = $this->upload->data();
				$post_photo = $avatar['file_name'];

				$idata['post_photo']=$post_photo;

			  

				}

						 

			}


			$this->db->where('id',$id)->update('tbl_post',$idata);

			$message='<div class="alert alert-success">Post Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/Edit-post/'.$id);

		}

		 

	}


	
	
}
