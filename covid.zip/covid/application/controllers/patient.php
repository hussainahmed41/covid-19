<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class patient extends CI_Controller {

	
	public function index()
	{
		$data['patient']=$this->db->select('count(id) as id,division_name')->from('tbl_user,tbl_division')->where('tbl_user.division_id=tbl_division.div_id')->group_by('division_id')->get()->result_array();
            
		$this->load->view('user_dashboard/inc/header');
		$this->load->view('user_dashboard/inc/navbar2');
		$this->load->view('user_dashboard/stat',$data);
		$this->load->view('user_dashboard/inc/footer');
	}
	
	
	
	
}
