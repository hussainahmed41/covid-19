<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class contact extends CI_Controller {

	public function index()
	{
		 
	   $this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('message', 'messages', 'required');
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
		
		
		
	
		
		if ($this->form_validation->run() == FALSE)
		{
			
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('contact');
		$this->load->view('inc/footer');
	
	
	}else{
			
			
				$idata['name']=$this->input->post('name');
				$idata['mobile']=$this->input->post('mobile');
				$idata['message']=$this->input->post('message');
				$idata['email']=$this->input->post('email');
				
				


			    $this->db->insert('tbl_message',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('contact');
			
			
		}
		
		
		 
	}
	
}
