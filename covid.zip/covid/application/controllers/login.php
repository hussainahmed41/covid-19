<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	
	public function index()
	{
           $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		   $this->form_validation->set_rules('password', 'Password', 'required');
		   
		   
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
	
	if ($this->form_validation->run()==FALSE) {
		
		
		$this->load->view('inc/header');
		$this->load->view('inc/navbar');
		$this->load->view('login');
		//$this->load->view('inc/footer');
		
		
	}else{

	$email=$this->input->post('email');
	$password=$this->input->post('password');
	
	$result = $this->db->where('email',$email)->where('password',$password)->get('tbl_user')->result_array();
	
	if(!empty($result)){
		
		$s_data['name']=$result[0]['name'];
		$s_data['email']=$result[0]['email'];
		$s_data['mobile']=$result[0]['mobile'];
		$s_data['type']=$result[0]['type'];
		$s_data['id']=$result[0]['id'];


		$this->session->set_userdata($s_data);

		
 

			$s_data ['email']=$result[0]['email'];
			$s_data ['name']=$result[0]['name'];
			$s_data ['mobile']=$result[0]['mobile'];
			$s_data ['type']=$result[0]['type'];
			$s_data ['id']=$result[0]['id'];
			
			if($result[0]['type']=='Admin'){
				
			 
                   redirect('Admin');	

                   
			}else if($result[0]['type']=='user'){
				
					 redirect('user_dashboard');	
			
				 
			
             
			}else{

			$message='<div class="alert alert-danger">Wrong email or Password</div>';

			$this->session->set_flashdata('message',$message);

			redirect('login');
			}

		 





	}else{
		
		
		$message='<div class="alert alert-danger">Invalid Email or Password</div>';
		
		$this->session->set_flashdata('message',$message);
		
		
		redirect('login');
		
	}
	}
}



}