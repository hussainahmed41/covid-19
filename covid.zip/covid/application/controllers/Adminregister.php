<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adminregister extends CI_Controller {

	
	public function index()
	{
		
		
		 $this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('verify_password', 'confirm password', 'required|matches[password]');
		
 
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
		
		if ($this->form_validation->run() == FALSE)
		{
		
		$this->load->view('admin/inc/header');
		$this->load->view('admin/register');
		$this->load->view('admin/inc/footer');
		
	}else{
	
	   	
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['password']=$this->input->post('password');
			    $idata['type']='admin';
				


				$this->db->insert('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('Adminregister');
			
			
		}
		
		
	}	 
	
}
