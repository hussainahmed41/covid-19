<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	
	public function index()
	{
		
		$this->form_validation->set_rules('name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('Password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_Password', 'confirm password', 'required|matches[Password]');
		
		$this->form_validation->set_message('required', 'The %s filed should not be empty');
		
		
		if ($this->form_validation->run() == FALSE)
		{

				
		$this->load->view('inc/header');
		 $this->load->view('inc/navbar');
		 $this->load->view('signup');
		 //$this->load->view('inc/footer');
			
		}else{
			
			
				$idata['name']=$this->input->post('name');
				$idata['email']=$this->input->post('email');
				$idata['Password']=$this->input->post('Password');
				$idata['type']='user';
				
				


				$this->db->insert('tbl_user',$idata);

				$message='<div class="alert alert-success">Data Inserted</div>';

				$this->session->set_flashdata('success',$message);

				redirect('signup');
			
			
		}
	}
	
	
}
