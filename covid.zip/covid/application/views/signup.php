<style>
.error{
	color:red;
}


</style>


<div class="container">

<br />
<br />
<br />
	 <h1 align="center"><u>Sign Up</u></h1>
		<br />
	 
		<div class="col-md-6 offset-3">

			<?=$this->session->flashdata('success')?>
	 
		<form action="" method="post">
		
		 <div class="form-group">
			<label for="exampleInputEmail1">Name</label>
			<input type="text" name="name" class="form-control" value="<?=set_value('name')?>" placeholder="Enter Name"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('name')?></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Email</label>
			<input type="text" name="email" class="form-control" value="<?=set_value('email')?>" placeholder="Enter email"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('email')?></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Password</label>
			<input type="password"  name="Password" class="form-control" value="<?=set_value('Password')?>" placeholder="Enter Password"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('Password')?></div>
			
			
		  <div class="form-group">
			<label for="exampleInputEmail1">Confirm Password</label>
			<input type="password"  name="confirm_Password" class="form-control" value="<?=set_value('confirm_Password')?>" placeholder="Enter confirm assword"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('confirm_Password')?></div>
			



		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		
		</div>
		
	</div>
	