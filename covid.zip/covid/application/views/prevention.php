


  <div class="site-wrap" >

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    
    

    


    <div class="hero-v1">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 mr-auto text-center text-lg-left">
            <span class="d-block subheading">Covid-19 Awareness</span>
            <h1 class="heading mb-3">Stay Safe<br>Stay Home.</h1>
            <p class="mb-5">COVID-19 Prevention Network conducts studies of vaccines and monoclonal antibodies to prevent the spread of the Coronavirus!</p>
            <p class="mb-4"><a href="#moreprevention" class="btn btn-primary">How to prevent</a></p>



          </div>
          <div class="col-lg-6">
            <figure class="illustration-2">
              <img src="<?=base_url()?>asset/img/protect.png" alt="Image" class="img-fluid">
            </figure>
          </div>
          <div class="col-lg-6"></div>
        </div>
      </div>
    </div>


    <!-- MAIN -->
    



    <div class="site-section bg-primary-light">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">

            <div class="row"></div>
            <div class="row">
              <div class="col-6 col-lg-6 mt-lg-5">
                <div class="media-v1 bg-1">
                  <div class="icon-wrap">
                    <span class="flaticon-stay-at-home"></span>
                  </div>
                  <div class="body">
                    <h3>Stay at home</h3>
                    <p>Stay at home and keep distance from the peoples!</p>
                  </div>
                </div>

                <div class="media-v1 bg-1">
                  <div class="icon-wrap">
                    <span class="flaticon-patient"></span>
                  </div>
                  <div class="body">
                    <h3>Wear facemask</h3>
                    <p>Use Mask for protecting yourself and others!</p>
                  </div>
                </div>
              </div>
              <div class="col-6 col-lg-6">
                <div class="media-v1 bg-1">
                  <div class="icon-wrap">
                    <span class="flaticon-social-distancing"></span>
                  </div>
                  <div class="body">
                    <h3>Keep social distancing</h3>
                    <p>Avoid all the crowdy and visible places!</p>
                  </div>
                </div>

                <div class="media-v1 bg-1">
                  <div class="icon-wrap">
                    <span class="flaticon-hand-washing"></span>
                  </div>
                  <div class="body">
                    <h3>Wash your hands</h3>
                    <p>Wash your hands again and again and use hand senitizer for more safety!!</p>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
            <div class="col-lg-5 ml-auto">
            <h2 class="section-heading mb-4">How to Prevent Coronavirus?</h2>
            
            <ul class="list-check list-unstyled mb-5">
			      <li>Stay at home</li>
                  <li>Wear mask</li>
                  <li>Use Sanitizer</li>
                  <li>Disinfect your home</li>
                  <li>Wash your hands</li>
                  <li>Frequent self-isolation</li>
                  <li>Avoid infected people</li>
                  <li>Avoid animals</li>
                  <li>Avoid handshaking</li>
                  <li>Aviod infected surfaces</li>
                  <li>Don't touch your face</li>
                  <li>Avoid droplets</li>
            </ul>

            <p><a href="<?=base_url()?>prevention" class="btn btn-primary">Read more about prevention</a></p>
          </div>
        </div>
      </div>
    </div>


  
    <div class="site-section bg-light">
      <div class="container" id="moreprevention">
        <div class="row mb-3">
          <div class="col-lg-7 text-center mx-auto">
            <h2 class="section-heading">More Preventions</h2>
            <p>Keep Personal protective equipment!</p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3">
            <div class="media-v1 bg-1">
              <div class="icon-wrap">
                <span class="flaticon-stay-at-home"></span>
              </div>
              <div class="body">
                <h3>Handwash</h3>
                <p>Wash your hand when you eat somthing or not!</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="media-v1 bg-1">
              <div class="icon-wrap">
                <span class="flaticon-patient"></span>
              </div>
              <div class="body">
                <h3> Facemask</h3>
                <p>Keep Facemask with you when you travell outside of the room!</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="media-v1 bg-1">
              <div class="icon-wrap">
                <span class="flaticon-social-distancing"></span>
              </div>
              <div class="body">
                <h3>Water</h3>
                <p>Bring water and wash face and hands with handwash!</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="media-v1 bg-1">
              <div class="icon-wrap">
                <span class="flaticon-hand-washing"></span>
              </div>
              <div class="body">
                <h3>Hand sanitizer</h3>
                <p>Use hand sanitizer when you touch anything outside or interrior!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
