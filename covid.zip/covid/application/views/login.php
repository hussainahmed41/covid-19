<style>
.error{
	color:red;
}


</style>


<div class="container">

	<br />
		<br />
		<br />
		<br />
	 <h1 align="center"><u>Log In</u></h1>
	
	 
		<div class="col-md-6 offset-3">

			<?=$this->session->flashdata('message')?>
	 
		<form action="<?=base_url()?>login" method="post">
		
		 <div class="form-group">
			<label for="exampleInputEmail1">Email</label>
			<input type="text" name="email" class="form-control" value="<?=set_value('email')?>" placeholder="Enter email"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('email')?></div>
		 
		
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Password</label>
			<input type="password"  name="password" class="form-control" value="<?=set_value('password')?>" placeholder="Enter Password"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('password')?></div>
			



		  <button type="submit" class="btn btn-primary">Log In</button>
		  </form>
		
		</div>
		
	</div>
	