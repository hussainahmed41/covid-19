


  <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    
   

    


    <div class="hero-v1">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 mr-auto text-center text-lg-left">
            <span class="d-block subheading">About</span>
            <h1 class="heading mb-3">About Us</h1>
            <p class="mb-5">Coronavirus disease 2019 (COVID-19) is a contagious respiratory and vascular disease!</p>
            <p class="mb-4"><a href="<?=base_url()?>prevention" class="btn btn-primary">How to prevent</a></p>



          </div>
          <div class="col-lg-6">
            <figure class="illustration">
              <img src="<?=base_url()?>asset/img/illustration.png" alt="Image" class="img-fluid">
            </figure>
          </div>
          
        </div>
      </div>
    </div>


    <!-- MAIN -->




   
    <div class="site-section">
      <div class="container">
        <div class="row mb-3">
          <div class="col-lg-7 text-center mx-auto">
            <h2 class="section-heading">Team</h2>
            <p>We work for unity and stay happy with society!</p>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4">
            <div class="team">
              <img src="<?=base_url()?>asset/img/hussain.JPG" alt="Image" class="img-fluid">
              <h3>Hussain Ahmed</h3>
               <p>Working As an employee for a long time with this site for the happiness of peoples.</p>
              <p>
                <span class="d-block mb-2"><strong>Connect on social</strong></span>
                <a href="#" class="p-2 icon-facebook"></a>
                <a href="#" class="p-2 icon-twitter"></a>
                <a href="#" class="p-2 icon-linkedin"></a>
                <a href="#" class="p-2 icon-instagram"></a>
              </p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="team">
              <img src="<?=base_url()?>asset/img/jafor.PNG" alt="Image" class="img-fluid">
              <h3>Abu Jafor</h3>
              <p>Working As an employee for a long time with this site for the happiness of peoples.</p>
               <p>
                <span class="d-block mb-2"><strong>Connect on social</strong></span>
                <a href="#" class="p-2 icon-facebook"></a>
                <a href="#" class="p-2 icon-twitter"></a>
                <a href="#" class="p-2 icon-linkedin"></a>
                <a href="#" class="p-2 icon-instagram"></a>
              </p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="team">
              <img src="<?=base_url()?>asset/img/sojib.PNG" alt="Image" class="img-fluid">
              <h3>Sojib Chandra</h3>
              <p>Working As an employee for a long time with this site for the happiness of peoples.</p>
              <p>
                <span class="d-block mb-2"><strong>Connect on social</strong></span>
                <a href="#" class="p-2 icon-facebook"></a>
                <a href="#" class="p-2 icon-twitter"></a>
                <a href="#" class="p-2 icon-linkedin"></a>
                <a href="#" class="p-2 icon-instagram"></a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>


  

   
    </div>

  