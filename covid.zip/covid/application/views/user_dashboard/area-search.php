<div class="container">

<br />
	 <h1 align="center"><u>Search Destination</u></h1>
		<br />
	 
		<div class="col-md-6 offset-3">

			
		<form action="" method="post">
		<div class="form-group">
			<label for="exampleInputEmail1">Select Destination</label>
			
			<select name="division_id" class="form-control" >	

				 <option  value="">---SELECT DIVISION---</option>

				<?php 	foreach ($division as $row) {  ?>
					 <option  <?php if(set_value('division_id')==$row['div_id']){ echo 'selected'; } elseif ($this->session->flashdata('division_id')==$row['div_id']){ echo 'selected'; }?> value="<?=$row['div_id']?>"><?=$row['division_name']?></option>
				<?php } ?>
				

			</select>	
			
		  </div>
			<div class="error"><?=form_error('division_id')?></div>
		
		

		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		<br>
		<?=$this->session->flashdata('success')?>
	 
		</div>
		
	</div>
	