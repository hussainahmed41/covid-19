<div class="container">

<br />
	 <h1 align="center"><u>Search Destination</u></h1>
		<br />
	 
		<div class="col-md-6 offset-3">

			
		<form action="" method="post">
		<div class="form-group">
			<label for="exampleInputEmail1">Select Destination</label>
			<!-- <input type="text"  name="area_id" class="form-control" value="<?=set_value('area_id')?>" placeholder="Enter Area id"  id="exampleInputEmail1" aria-describedby="emailHelp"> -->


			<select name="area_id" class="form-control" >	

				 <option  value="">---SELECT AREA---</option>

				<?php 	foreach ($area as $row) {  ?>
					 <option  <?php if(set_value('area_id')==$row['area_id']){ echo 'selected'; } ?> value="<?=$row['area_id']?>"><?=$row['area_name']?></option>
				<?php } ?>
				

			</select>	
			
		  </div>
			<div class="error"><?=form_error('area_id')?></div>
		
		

		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		<br>
		<?=$this->session->flashdata('success')?>
	 
		</div>
		
	</div>
	