<style>
.error{
	color:red;
}


</style>


<div class="container">

<br />
	 <h1 align="center"><u>Other Information</u></h1>
		<br />
	 
		<div class="col-md-6 offset-3">

			<?=$this->session->flashdata('success')?>
	 
		<form action="" method="post">
		 
		  <div class="form-group">
			<label for="exampleInputEmail1">Mobile</label>
			<input type="text" name="mobile" class="form-control" value="<?=set_value('mobile')?>" placeholder="Enter mobile"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('mobile')?></div>
		  
		   
		  
		   <div class="form-group">
			<label for="exampleInputEmail1">Weight</label>
			<input type="text" name="weight" class="form-control" value="<?=set_value('weight')?>" placeholder="Enter weight"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('weight')?></div>


		  <div class="form-group">
			<label for="exampleInputEmail1">Date Of Birth</label>
			<input type="date" name="dob" class="form-control" value="<?=set_value('dob')?>"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('dob')?></div>
		  
		
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Address</label>
			<input type="text"  name="address" class="form-control" value="<?=set_value('address')?>" placeholder="Enter Address"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('address')?></div>
			
			<div class="form-group">
			<label for="exampleInputEmail1">Select Division</label>
			<!-- <input type="text"  name="area_id" class="form-control" value="<?=set_value('area_id')?>" placeholder="Enter Area id"  id="exampleInputEmail1" aria-describedby="emailHelp"> -->


			<select name="division_id" class="form-control" >	

				 <option  value="">---SELECT DIVISION---</option>

				<?php 	foreach ($division as $row) {  ?>
					 <option  <?php if(set_value('division_id')==$row['div_id']){ echo 'selected'; } ?> value="<?=$row['div_id']?>"><?=$row['division_name']?></option>
				<?php } ?>
				

			</select>	
			
		  </div>
			<div class="error"><?=form_error('division_id')?></div>
			


		 <div class="form-group">
			<label for="exampleInputPassword1">Gender</label> <br>	
			<input type="radio" name="gender" value="male"    <?php if(set_value('gender')=='male') { echo 'checked'; }?> > Male

			<input type="radio" name="gender" value="female"    <?php if(set_value('gender')=='female') { echo 'checked'; }?> > Female
		  </div>
		 <div class="error"><?=form_error('gender')?></div>
		 
		 

		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		
		</div>
		
	</div>
	