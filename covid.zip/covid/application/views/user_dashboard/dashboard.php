

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->

            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                   
                                    
                                
                                </div>
								
							
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?=base_url()?>asset/admin-asset/images/icon/boy.png" alt="" />
                                        </div>
                                       
                                        <div class="account-dropdown js-dropdown">
                                            
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="<?=base_url()?>user_dashboard/edit_otherinfo">
                                                        <i class="zmdi zmdi-settings"></i>Edit Profile</a>
                                                </div>
                                               
                                            </div>
											
                                            <div class="account-dropdown__footer">
                                                <a href="<?=base_url()?>Logout">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
							</div>
							
                        </div>
						
                    </div>
					
                </div>
				
            </header>
		 <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12 ">
                                <h1 class="title-1  text-center mt-5"><b>Welcome To</b></h1><br>
                                <h5 class="title-1  text-center"><b>Dashbord!</b></h5>
                               
                            </div>
                        </div>
						  
                    </div>
                </div>
            </div>
        </div>

 
   