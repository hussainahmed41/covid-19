
</br>
</br>
</br>
</br>

<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	exportEnabled: true,
	theme: "light1", // "light1", "light2", "dark1", "dark2"
	title:{
		text: "Division wise COVID patient statistics "
	},
  	axisY: {
      includeZero: true
    },
	data: [{
		type: "column", //change type to bar, line, area, pie, etc
		//indexLabel: "{y}", //Shows y value on all Data Points
		indexLabelFontColor: "#5A5757",
      	indexLabelFontSize: 16,
		indexLabelPlacement: "outside",
		dataPoints:  [
		 
		<?php $i=10; foreach ($patient as $patient){
			
		
		
		?>
			{ x: <?=$i?>, y: <?=$patient['id']?>,indexLabel:"<?=$patient['division_name']?>" },
			
	<?php $i=$i+10; } ?>		
			
		]
	}]
});
chart.render();

}
</script>
<div class="container col-md-8">
<div  id="chartContainer" style="height: 400px; width: 100%;"></div></br>
<p class="text-justify ">As a result of COVID-19 many regions have imposed lockdowns, curfews and quarantines alongside new 
legislation and evacuations, or other restrictions for citizens of or recent travelers to the most affected areas.Other regions 
have imposed global restrictions that apply to all foreign countries and territories, 
or prevent their own citizens from travelling overseas.</p>
</div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</br>
</br>
</br>
