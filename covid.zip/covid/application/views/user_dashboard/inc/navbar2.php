

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="<?=base_url()?>asset/admin-asset/images/icon/logo.png" width="120" height="120"  alt="logo">
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="<?=base_url()?>user_dashboard">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                           
                        </li>
						 <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Location</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>user_dashboard/area-search">Area Search</a>
                                </li>
                               
								<li>
                                    <a href="<?=base_url()?>user_dashboard/subarea-search">Sub-Area Search</a>
                                </li>
								<li>
                                    <a href="<?=base_url()?>patient">Live News</a>
                                </li>
								
                            </ul>
                        </li>
						
					
                    </ul>
                </nav>
            </div>
        </aside>
  
