


  <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>


  <div class="site-wrap" ">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
<div class="hero-v1">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-lg-6 text-center mx-auto">
            <span class="d-block subheading">Updates</span>
            <h1 class="heading mb-3">Blog Posts</h1>
            <p class="mb-5">Recently Updated News and Articles are available!</p>
          </div>
          
        </div>
      </div>
    </div>
 </br>
</br>



    <!-- MAIN -->




    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-7 mx-auto text-center">
            <h2 class="mb-4 section-heading">Latest News & Articles</h2>
            <p>Upgraded news are available very quickly from the very begeninng of published!</p>
          </div>
        </div>

        <div class="row">
		
		 <?php foreach ($post as $row) {  ?>
		 
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5">
            <div class="post-entry">
              <a href="#" class="thumb">
                
                <img src="<?=base_url()?>image/<?=$row['post_photo']?>" alt="Image" class="img-fluid">
              </a>
              <div class="post-meta text-center">
                <a href="">
                  <span class="icon-user"></span>
                  <span>Admin</span>
                </a>
				<span class="post_date"><?=date('Y-m-d',$row['post_date'])?></span>
            
              </div>
              <h3 class="post-title text-justify"><a href="#"><?=$row['post_name']?></a></h3>
			  <div class="content">
              <p class="text-justify"><?=substr($row['post_detail'],0,200)?></p>
              
              <a href="#" class="blog-btn"><b>Read more</b><i class="fa fa-chevron-right"></i></a>
            </div>
            </div>
          </div>
		  
		   <!-- post-item end -->

           <?php  } ?>
		  
		 
      </div>
	   <div class="row">
          <div class="col-lg-12 text-center">
            <div class="custom-pagination">
              <a href="#">1</a>
              <a href="#" class="active">2</a>
              <a href="#">3</a>
              <a href="#">4</a>
            </div>
          </div>
        </div>
    </div>

<br>

