<style>
.error{
	color:red;
	1
}
</style>

 <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <div class="hero-v1">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-lg-6 text-center mx-auto">
            <span class="d-block subheading">Contact</span>
            <h1 class="heading mb-3">Get In Touch</h1>
            <p class="mb-5">Be closer to us with your any Qury,we are always waiting for your voice!</p>
          </div>
          
        </div>
      </div>
    </div>


    <!-- MAIN -->

   <!------------------contact------------------>

<div class="container-fluid  pt-5 pb-5" id="contactid">
<div class="section_header  mb-5 mt-4">
<h1 class="text-center" >Contact Us</h1>
<div class="container ">
<div class="row">
<div class="col-lg-8 offset-lg-2 col-12">

<?=$this->session->flashdata('success')?>
<form action="" method="post">

<div class="form-group">
    <label >Username</label>
    <input type="text" class="form-control" name="name" value="<?=set_value('name')?>" placeholder="Enter your name"  >
  </div>
   <div class="error"><?=form_error('name')?></div>
		  
  <div class="form-group">
    <label >Mobile</label>
    <input type="number" class="form-control" name="mobile" value="<?=set_value('mobile')?>" placeholder="Enter your mobile" >
  </div>
 <div class="error"><?=form_error('mobile')?></div>
 
 <div class="form-group">
    <label >Email</label>
    <input type="text" class="form-control" name="email" value="<?=set_value('email')?>" placeholder="Enter your email" >
  </div>
 <div class="error"><?=form_error('email')?></div>
		  
 <div class="form-group">
    <label for="exampleFormControlTextarea1">Message</label>
    <textarea name="message" class="form-control"  id="exampleFormControlTextarea1" rows="3"> <?=set_value('message')?></textarea>
  </div>
  
   <div class="error"><?=form_error('message')?></div>
		  
  <button type="submit" class="btn btn-primary ">Submit</button>
</form>
</div>

        <div class="col-lg-4">
            <h3 class="mb-3 side-title">Quick info</h3>
            <div class="quick-contact">

              <div class="d-flex">
                <span class="icon-room"></span>
                <address>
                  Sylhet, 3130, Bangladesh
                </address>
              </div>
              <div class="d-flex">
                <span class="icon-phone"></span>
                <a href="#">+8801796 648 209</a>
              </div>
              <div class="d-flex">
                <span class="icon-envelope"></span>
                <a href="#">hussain.edu.bd.com</a>
              </div>
              <div class="d-flex">
                <span class="icon-globe"></span>
                <a href="#">https://website.com</a>
              </div>
            </div>
          </div>
		  </div>
		</div>
        </div>
  </div>
  
