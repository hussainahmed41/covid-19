 <header class="site-navbar light js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">

          <div class="col-6 col-xl-2">
            <div class="mb-0 site-logo">
			<a href="<?=base_url()?>welcome" class="mb-0"><img src="<?=base_url()?>asset/img/logo.png " width="170" height="100"></a>
			</div>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <a href="<?=base_url()?>" class="nav-link"><li class="active">Home</li></a>
				   <a href="<?=base_url()?>symptoms" class="nav-link"><li class="nav-item">Symptoms</li></a>
                <a href="<?=base_url()?>prevention" class="nav-link" ><li class="nav-item">Prevention</li></a>
             <a href="<?=base_url()?>about" class="nav-link"><li class="nav-item">About</li></a>
                <a href="<?=base_url()?>blog" class="nav-link"><li class="nav-item" >Blog</li></a>
                <a href="<?=base_url()?>contact" class="nav-link"><li class="nav-item">Contact</li></a>
				<a href="<?=base_url()?>login" class="nav-link"><li class="nav-item" >Log IN</li></a>
                <a href="<?=base_url()?>signup" class="nav-link"><li class="nav-item">Sign Up</li></a>
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;">
		  <a href="<?=base_url()?>" class="site-menu-toggle js-menu-toggle float-right">
		  <span class="icon-menu h3 text-black"></span>
		  </a>
		  </div>

        </div>
      </div>

    </header>
