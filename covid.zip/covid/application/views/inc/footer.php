<style>
.footer{
	min-height:50px;
	background-color:#8000FF;
	color:#C0C0C0;
	font-size:15px;
}

</style>

<div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
           <p class="text-center mt-2"><b>Developed By-</b> Md Hussain Ahmed</p>
          </div>
		  
		  
        </div>
       
        </div>
      </div>
    </div>

  <!-- .site-wrap -->

  <script src="<?=base_url()?>asset/js/jquery-3.3.1.min.js"></script>
  <script src="<?=base_url()?>asset/js/jquery-ui.js"></script>
  <script src="<?=base_url()?>asset/js/popper.min.js"></script>
  <script src="<?=base_url()?>asset/js/bootstrap.min.js"></script>
  <script src="<?=base_url()?>asset/js/owl.carousel.min.js"></script>
  <script src="<?=base_url()?>asset/js/jquery.countdown.min.js"></script>
  <script src="<?=base_url()?>asset/js/jquery.easing.1.3.js"></script>
  <script src="<?=base_url()?>asset/js/aos.js"></script>
  <script src="<?=base_url()?>asset/js/jquery.fancybox.min.js"></script>
  <script src="<?=base_url()?>asset/js/jquery.sticky.js"></script>
  <script src="<?=base_url()?>asset/js/isotope.pkgd.min.js"></script>


  <script src="<?=base_url()?>asset/js/main.js"></script>


</body>
</html>