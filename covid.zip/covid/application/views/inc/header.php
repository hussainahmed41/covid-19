<!doctype html>
<html lang="en">
<head>
  <title>Covid </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    

  <link href="<?=base_url()?>asset/https://fonts.googleapis.com/css2?family=Mulish:wght@400;700;900&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?=base_url()?>asset/fonts/icomoon/style.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?=base_url()?>asset/css/jquery-ui.css">
  <link rel="stylesheet" href="<?=base_url()?>asset/css/owl.carousel.min.css">
  <link rel="stylesheet" href="<?=base_url()?>asset/css/owl.theme.default.min.css">
  <link rel="stylesheet" href="<?=base_url()?>asset/css/owl.theme.default.min.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="<?=base_url()?>asset/fonts/flaticon-covid/font/flaticon.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/css/aos.css">

  <link rel="stylesheet" href="<?=base_url()?>asset/css/style.css">

</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">