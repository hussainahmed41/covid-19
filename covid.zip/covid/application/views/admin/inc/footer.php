                             

    <!-- Jquery JS-->
    <script src="<?=base_url()?>asset/admin-asset/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="<?=base_url()?>asset/admin-asset/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="<?=base_url()?>asset/admin-asset/vendor/slick/slick.min.js">
    </script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/wow/wow.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/animsition/animsition.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/select2/select2.min.js">
    </script>

	
	<!-- full calendar requires moment along jquery which is included above -->
    <script src="<?=base_url()?>asset/admin-asset/vendor/fullcalendar-3.10.0/lib/moment.min.js"></script>
    <script src="<?=base_url()?>asset/admin-asset/vendor/fullcalendar-3.10.0/fullcalendar.js"></script>
	
   
<!-- Main JS-->
    <script src="<?=base_url()?>asset/admin-asset/js/main.js"></script>


</body>

</html>
<!-- end document-->
