

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="<?=base_url()?>asset/admin-asset/images/icon/logo.png" width="120" height="120"  alt="logo">
                  
				</a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="<?=base_url()?>Admin">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                           
                        </li>
						<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Post</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Admin/add-post">Add-Post</a>
                                </li>
								 <li>
                                    <a href="<?=base_url()?>Admin/view-post">View-Post</a>
                                </li>
                              	
                            </ul>
                        </li>
						
						<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>All Messages</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Admin/view-message">View message</a>
                                </li>
                              	
                            </ul>
                        </li>
						
						 <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Users</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Admin/add-user">Add user</a>
                                </li>
                                <li>
                                    <a href="<?=base_url()?>Admin/view-user">View user</a>
                                </li>
								
                            </ul>
                        </li>
						
						
						 <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Division</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Admin/add-division">Add Division</a>
                                </li>
                                <li>
                                    <a href="<?=base_url()?>Admin/view-division">View Division</a>
                                </li>
                              
                            </ul>
                        </li>
						
						
						 <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Area</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Admin/add-area">Add Area</a>
                                </li>
                                <li>
                                    <a href="<?=base_url()?>Admin/view-area">View Area</a>
                                </li>
                              
                            </ul>
                        </li>
						
						
						
                       
                      <!----  <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>Pages</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?=base_url()?>Adminlogin">Login</a>
                                </li>
                                <li>
                                    <a href="<?=base_url()?>Adminregister">Register</a>
                                </li>
                                <li>
                                    <a href="<?=base_url()?>Adminforgetpass">Forget Password</a>
                                </li>
                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-desktop"></i>UI Elements</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="button.html">Button</a>
                                </li>
                                <li>
                                    <a href="badge.html">Badges</a>
                                </li>
                                <li>
                                    <a href="tab.html">Tabs</a>
                                </li>
                                <li>
                                    <a href="card.html">Cards</a>
                                </li>
                                <li>
                                    <a href="alert.html">Alerts</a>
                                </li>
                                <li>
                                    <a href="progress-bar.html">Progress Bars</a>
                                </li>
                                <li>
                                    <a href="modal.html">Modals</a>
                                </li>
                                <li>
                                    <a href="switch.html">Switchs</a>
                                </li>
                                <li>
                                    <a href="grid.html">Grids</a>
                                </li>
                                <li>
                                    <a href="fontawesome.html">Fontawesome Icon</a>
                                </li>
                                <li>
                                    <a href="typo.html">Typography</a>
                                </li>--->
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->
