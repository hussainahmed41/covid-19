<div class="container">

<br />
	 <h1 align="center"><u>Add Area</u></h1>
		<br />
	 
		<div class="col-md-6 offset-3">

			<?=$this->session->flashdata('success')?>
	 
		<form action="<?=base_url()?>Admin/add-area" method="post">
		<div class="form-group">
			<label for="exampleInputEmail1">Select Division</label>
			<!-- <input type="text"  name="area_id" class="form-control" value="<?=set_value('area_id')?>" placeholder="Enter Area id"  id="exampleInputEmail1" aria-describedby="emailHelp"> -->


			<select name="division_id" class="form-control" >	

				 <option  value="">---SELECT DIVISION---</option>

				<?php 	foreach ($division as $row) {  ?>
					 <option  <?php if(set_value('division_id')==$row['div_id']){ echo 'selected'; } ?> value="<?=$row['div_id']?>"><?=$row['division_name']?></option>
				<?php } ?>
				

			</select>	
			
		  </div>
			<div class="error"><?=form_error('division_id')?></div>
		
		 <div class="form-group">
			<label for="exampleInputEmail1">Area</label>
			<input type="text" name="area_name" class="form-control" value="<?=set_value('area_name')?>" placeholder="Enter area"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('area_name')?></div>

		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		
		</div>
		
	</div>
	