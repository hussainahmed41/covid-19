 
	 
	 
	 
	 
	 <div class="container"  align="center">

	 <br />
	 <h1 align="center"><u>All Messages</u></h1>
	 	 <br />
	 		<table  class="table table-striped "  >
	 		
	 		<tr>
	 			
	 		
	 			<th>Name</th>
				<th>Mobile</th>
				<th>Email</th>
				<th>Message</th>
				
				
	 			<th>Delete</th>
	 		</tr>

	 		<?php  foreach ($user as $user) {  ?>
	 			 
	 		

	 		<tr>
	 			
	 		
	 			<td><?=$user['name']?></td>
				<td><?=$user['mobile']?></td>
				<td><?=$user['email']?></td>
	 			<td><?=$user['message']?></td>
				
				
				 
	 	
	 		<!--<td><a href="<?=base_url()?>user/edit-user/<?=$user['message_id']?>"><button class="btn btn-success">Edit</button></a></td>-->
	 			<td><a href="<?=base_url()?>Admin/delete-message/<?=$user['message_id']?>"><button class="btn btn-danger">Delete</button></a></td>
	 		</tr>

	 		<?php } ?>
	 			
	 		</table>
	 		
	 		
	 
	 
		
	</div>
	 