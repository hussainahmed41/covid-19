
	 
	 <div class="container">
	 
		<br />
	 
		<div class="col-md-6 offset-3">

			<?=$this->session->flashdata('success')?>
	 
		<!--<form action="<?=base_url()?>user/edit-user/<?=$user[0]['id']?>" method="post">-->
		<form action="" method="post">
		
		 <div class="form-group">
			<label for="exampleInputEmail1">Name</label>
			<input type="text" name="name" class="form-control" value="<?php if(set_value('name')){ echo set_value('name'); }else{ echo $user[0]['name']; } ?>" placeholder="Enter Name"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('name')?></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Email</label>
			<input type="text" name="email" class="form-control" value="<?php if(set_value('email')){ echo set_value('email'); }else{ echo $user[0]['email']; } ?>" placeholder="Enter email"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('email')?></div>
		  
		   <div class="form-group">
			<label for="exampleInputEmail1">Mobile</label>
			<input type="text" name="mobile" class="form-control" value="<?php if(set_value('mobile')){ echo set_value('mobile'); }else{ echo $user[0]['mobile']; } ?>" placeholder="Enter mobile"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('mobile')?></div>
		  
		   <div class="form-group">
			<label for="exampleInputEmail1">Weight</label>
			<input type="text" name="weight" class="form-control" value="<?php if(set_value('weight')){ echo set_value('weight'); }else{ echo $user[0]['weight']; } ?>" placeholder="Enter weight"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('weight')?></div>


		  <div class="form-group">
			<label for="exampleInputEmail1">Date of Birth</label>
			<input type="text" name="dob" class="form-control" value="<?php if(set_value('dob')){ echo set_value('dob'); }else{ echo $user[0]['dob']; } ?>" placeholder="Enter Date of Birth"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
		  <div class="error"><?=form_error('dob')?></div>
		  
		  <div class="form-group">
			<label for="exampleInputEmail1">Password</label>
			<input type="text"  name="password" class="form-control" value="<?php if(set_value('password')){ echo set_value('password'); }else{ echo $user[0]['password']; } ?>" placeholder="Enter password"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('password')?></div>
			
			 <div class="form-group">
			<label for="exampleInputEmail1">Confirm Password</label>
			<input type="text"  name="confirm_password" class="form-control" value="<?php if(set_value('confirm_password')){ echo set_value('confirm_password'); }else{ echo $user[0]['password']; } ?>" placeholder="Enter confirm password"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('confirm_password')?></div>
			
			 <div class="form-group">
			<label for="exampleInputEmail1">Address</label>
			<input type="text"  name="address" class="form-control" value="<?php if(set_value('address')){ echo set_value('address'); }else{ echo $user[0]['address']; } ?>" placeholder="Enter Address"  id="exampleInputEmail1" aria-describedby="emailHelp">
			
		  </div>
			<div class="error"><?=form_error('address')?></div>
			<div class="form-group">
			<label for="exampleInputEmail1">Select Division</label>
			<!-- <input type="text"  name="area_id" class="form-control" value="<?=set_value('area_id')?>" placeholder="Enter Area id"  id="exampleInputEmail1" aria-describedby="emailHelp"> -->


			<select name="division_id" class="form-control" >	

				 <option  value="">---SELECT DIVISION---</option>

				<?php 	foreach ($division as $row) {  ?>
					 <option  <?php if(set_value('division_id')==$row['div_id']){ echo 'selected'; }else if($user[0]['division_id']==$row['div_id']){ echo 'selected'; } ?> value="<?=$row['div_id']?>"><?=$row['division_name']?></option>
				
				
				<?php } ?>
				

			</select>	
			
		  </div>

			
		 

		  <div class="form-group">
			<label for="exampleInputPassword1">Gender</label> <br>	
			<input type="radio" name="gender" value="male"    <?php if(set_value('gender')=='male') { echo 'checked'; }else if($user[0]['gender']=='male'){ echo 'checked'; }  ?> > Male

			<input type="radio" name="gender" value="female"    <?php if(set_value('gender')=='female') { echo 'checked'; }else if($user[0]['gender']=='female'){ echo 'checked'; } ?> > Female
		  </div>
		 <div class="error"><?=form_error('gender')?></div>
		 
		 
		  <div class="form-group">
			<label for="exampleInputPassword1">Condition</label> <br>	
			<input type="radio" name="conditions" value="ILL"    <?php if(set_value('conditions')=='ILL') { echo 'checked'; }else if($user[0]['conditions']=='ILL'){ echo 'checked'; }  ?> > ILL

			<input type="radio" name="conditions" value="WELL"    <?php if(set_value('conditions')=='WELL') { echo 'checked'; }else if($user[0]['conditions']=='WELL'){ echo 'checked'; } ?> > WELL
		  </div>
		 <div class="error"><?=form_error('conditions')?></div>



		  
		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
		
		</div>
		
	</div>
