<style>
.error{
	
	color:red;
}



</style>


    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="<?=base_url()?>asset/admin-asset/images/icon/logo.png" width="120" height="120" alt="logo">
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="" method="post">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="name" value="<?=set_value('name')?>" placeholder="Username" >
                                </div>
								 <div class="error"><?=form_error('name')?></div>
								 
								 
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input class="au-input au-input--full" type="email" name="email" value="<?=set_value('email')?>"placeholder="Email">
                                </div>
								 <div class="error"><?=form_error('email')?></div>
								 
								 
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password"value="<?=set_value('password')?>" placeholder="Password">
                                </div>
								 <div class="error"><?=form_error('password')?></div>
								 
								 
								
								
								<div class="form-group">
                                    <label>Veerify Password</label>
                                    <input class="au-input au-input--full" type="password" name="verify_password" value="<?=set_value('verify_password')?>" placeholder="verify password">
                                </div>
								 <div class="error"><?=form_error('verify_password')?></div>
                               
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Sign Up</button>
                                
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    