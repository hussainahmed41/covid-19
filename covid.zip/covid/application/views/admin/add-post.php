  <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
         <br />
	 <h1 align="center"><u>Add Post</u></h1>
		<br />
	 

          <div class="row mb-3">
          <div class="col-md-6 offset-3">


                   <form action="" method="post" enctype="multipart/form-data" >

                        <?php echo $this->session->flashdata('message'); ?>


                         <div class="form-group"> 
                            <input type="text" class="form-control input-lg" value="<?=set_value('post_name')?>" placeholder="Post Title" name="post_name">

                            <div class="error"><?=form_error('post_name')?></div>

                        </div>


                        <div class="form-group"> 
                            <input type="date" class="form-control input-lg" value="<?=set_value('post_date')?>" placeholder="Post date" name="post_date">

                            <div class="error"><?=form_error('post_date')?></div>

                        </div>


                         


                        <div class="form-group"> 
                           
                             <textarea name="post_detail" class="form-control input-lg" ><?=set_value('post_detail')?></textarea>

                            <div class="error"><?=form_error('post_detail')?></div>

                        </div>
 


                        <div class="form-group"> 
            
                           <input type="file" name="post_photo">

                        </div>


 
                      
                         <div class="form-group"> 
            
                            <button type="submit" class="btn btn-primary">Add post</button>

                        </div>

                        </form>


           
            </div>
           
        
          </div>
          <!--Row-->

          
