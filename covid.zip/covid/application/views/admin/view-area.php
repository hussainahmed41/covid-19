 
	 
	 
	 
	 
	 <div class="container"  align="center">

	 <br />
	 <h1 align="center"><u>Area List</u></h1>
	 	 <br />
	 		<table  class="table table-striped"  >
	 		
	 		<tr>
	 			
	 		
	 			
	 			<th>Division Name</th>
	 			<th>Area Name</th>
				<th>Edit</th>
	 			<th>Delete</th>
	 		</tr>

	 		<?php  foreach ($user as $user) {  ?>
	 			 
	 		

	 		<tr>
	 			
	 		
				<td><?=$user['division_name']?></td>
				<td><?=$user['area_name']?></td>
				 
	 	
	 			<td><a href="<?=base_url()?>Admin/edit-area/<?=$user['area_id']?>"><button class="btn btn-success">Edit</button></a></td>
	 			<td><a href="<?=base_url()?>Admin/delete-area/<?=$user['area_id']?>"><button class="btn btn-danger">Delete</button></a></td>
	 		</tr>

	 		<?php } ?>
	 			
	 		</table>
	 		
	 		
	 
	 
		
	</div>
	 