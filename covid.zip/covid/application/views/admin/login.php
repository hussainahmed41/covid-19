<style>

.error{	
color:red;	
	
}

</style>




    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="<?=base_url()?>asset/admin-asset/images/icon/logo.png" width="120" height="120" alt="logo">
								
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="" method="post">
							<?php echo $this->session->flashdata('message'); ?>
                               <div class="form-group"> 
			                        <label for="">Email</label>
			                             <input type="text" class="form-control input-lg" value="<?=set_value('email')?>" placeholder="User email" name="email">
			                          
		                             </div>
									  <div class="error"><?=form_error('email')?></div>
								
                                <div class="form-group"> 
			                        <label for="">password</label>
			                             <input type="password" class="form-control input-lg" value="<?=set_value('password')?>" placeholder="Password" name="password">
			                           
		                             </div>
									 <div class="error"><?=form_error('password')?></div>
								
								
								 <div class="form-group"> 
			                        <label for="">Verify password</label>
			                             <input type="password" class="form-control input-lg" value="<?=set_value('verify_password')?>" placeholder=" verify password" name="verify_password">
			                          
		                             </div>
								 <div class="error"><?=form_error('verify_password')?></div>
								
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                               
                            </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
