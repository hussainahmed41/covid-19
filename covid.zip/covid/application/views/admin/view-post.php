  <!-- Container Fluid-->
        <div class="container-fluid" align="center">
          <br />
	 <h1 align="center"><u>Post list</u></h1>
	 	 <br />
                 
                  <table class="table table-striped">
                   
                      <tr>
					  
                       <th>Post Title</th>
                        <th>Post Date</th>
                        <th>Post Detail</th>
						 <th>Post Image</th>
                       <th>Action</th>
					   
                      </tr>
					  
					    <?php if ($post){ ?>
                    
                    <tbody>
                      <?php foreach ($post as $post) {  ?>
                         
                    
                      <tr>
                        <td><?=$post['post_name']?></td>
                       <td><?=date('Y-m-d',$post['post_date'])?></td>
                        <td><?=$post['post_detail']?></td>
						<td><img src="<?=base_url()?>image/<?=$post['post_photo']?>" width="200px" height="150px;" alt=""></td>
                        
                        <td>
                          <a href="<?=base_url()?>Admin/edit-post/<?=$post['id']?>" class="btn btn-sm btn-primary">Edit</a>
                          <a href="<?=base_url()?>Admin/delete-post/<?=$post['id']?>" class="btn btn-sm btn-danger">Delete</a>

                        </td>
                      </tr>

                       <?php  } ?>
                    
                    </tbody>
                  </table>

                <?php  } ?>
               
               
        
            <!-- Message From Customer-->
     
          <!--Row-->

          

        