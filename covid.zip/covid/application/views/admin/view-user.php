 <div class="container"  align="center">

	 <br />
	 <h1 align="center"><u>Users List</u></h1>
	 	 <br />
	 		<table  class="table table-striped"  >
	 		
	 		<tr>
	 			
	 		
	 			<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>weight</th>
				<th>Gender</th>
				<th>Date of Birth</th>
				<th>Password</th>
				<th>Address</th>
				<th>condition</th>
	 			<th>Divison Name</th>
			 
				<th>Edit</th>
	 			<th>Delete</th>
	 		</tr>

	 		<?php  foreach ($user as $user) {  ?>
	 			 
	 		

	 		<tr>
	 			
	 		
	 			<td><?=$user['name']?></td>
	 			<td><?=$user['email']?></td>
	 			<td><?=$user['mobile']?></td>
				<td><?=$user['weight']?></td>
				<td><?=$user['gender']?></td>
				<td><?=$user['dob']?></td>
				<td><?=$user['password']?></td>
				<td><?=$user['address']?></td>
				<td><?=$user['conditions']?></td>
	 			<td><?=$user['division_name']?></td>
				 
	 	
	 			<td><a href="<?=base_url()?>Admin/edit-user/<?=$user['id']?>"><button class="btn btn-success">Edit</button></a></td>
	 			<td><a href="<?=base_url()?>Admin/delete-user/<?=$user['id']?>"><button class="btn btn-danger">Delete</button></a></td>
	 		</tr>

	 		<?php } ?>
	 			
	 		</table>
	 		
	 		
	 
	 
		
	</div>
	 